from typing import Optional

import psycopg2
from psycopg2.extensions import connection as Psycopg2Connection

from nexuslabdata.connection.base import ConnectionState, ConnectionWrapper
from nexuslabdata.connection.base.events import ConnectionOpened
from nexuslabdata.connection.postgresql.postgresql_credential import (
    PostgreSQLCredential,
)


class PostgreSQLConnectionWrapper(
    ConnectionWrapper[PostgreSQLCredential, Psycopg2Connection]
):
    """A wrapper for a PostgreSQL connection.

    This class manages the lifecycle of a PostgreSQL connection, including opening and closing
    the connection, and provides methods for interacting with the database.
    """

    def __init__(
        self,
        name: str,
        credentials: PostgreSQLCredential,
        state: ConnectionState = ConnectionState.INIT,
        connection: Optional[Psycopg2Connection] = None,
    ) -> None:
        super().__init__(
            name=name,
            credentials=credentials,
            state=state,
            connection=connection,
        )

    @property
    def type(self) -> str:
        """Return the type of the connection."""
        return "postgresql"

    def _get_active_catalog(self) -> Optional[str]:
        """Return the active catalog (database) for the connection."""
        return self.credentials.database

    def _get_active_schema(self) -> Optional[str]:
        """Return the active schema for the connection."""
        return self.credentials.schema

    def open(self) -> "PostgreSQLConnectionWrapper":
        """Open the PostgreSQL connection.
        If the connection is already opened, it does nothing.
        If the connection is not opened, it attempts to open it using the provided credentials.
        Returns:
            PostgreSQLConnectionWrapper: The current instance of the connection wrapper.
        """
        if self.is_opened():
            self.log_info(f"Connection {self.name} is already opened.")
            return self
        if self.credentials is not None:
            self._open_postgresql_connection()
        return self

    def _open_postgresql_connection(self) -> None:
        """Open the PostgreSQL connection using the provided credentials."""
        self.log_info("PostgreSQL Connection to be opened")
        self.log_debug(f"Host: {self.credentials.host}")
        self.log_debug(f"Port: {self.credentials.port}")
        self.log_debug(f"Database: {self.credentials.database}")
        self.log_debug(f"User: {self.credentials.user}")
        self.log_debug("Password: ***")

        self.connection = psycopg2.connect(
            host=self.credentials.host,
            port=self.credentials.port,
            database=self.credentials.database,
            user=self.credentials.user,
            password=self.credentials.password,
        )
        self.state = ConnectionState.OPEN
        self.log_event(ConnectionOpened(connection_name=self.name))
