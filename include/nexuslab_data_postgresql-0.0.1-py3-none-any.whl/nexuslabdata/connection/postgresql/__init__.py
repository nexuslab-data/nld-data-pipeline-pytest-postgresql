from nexuslabdata.connection.postgresql.postgresql_data_type import (
    PostgreSQLDataTypes,
)
from nexuslabdata.connection.postgresql.postgresql_credential import (
    PostgreSQLCredential,
)
from nexuslabdata.connection.postgresql.postgresql_connection import (
    PostgreSQLConnectionWrapper,
)
from nexuslabdata.connection.postgresql.postgresql_service import (
    PostgreSQLService,
)
from nexuslabdata.connection.base import ConnectionAdapterPlugin


Plugin = ConnectionAdapterPlugin(
    service_class=PostgreSQLService,
    connection_wrapper_class=PostgreSQLConnectionWrapper,
    credentials_class=PostgreSQLCredential,
    include_path="postgresql",
)

__all__ = [
    "PostgreSQLCredential",
    "PostgreSQLConnectionWrapper",
    "PostgreSQLService",
    "PostgreSQLDataTypes",
]
