from typing import List, Optional

from psycopg2 import sql

class PostgreSQLQueryBuilder():
    @classmethod
    def create_load_dataframe_data_query(
            cls,
            schema_name: str,
            table_name: str,
            insert_column_list: List[str],
            conflict_merge_fields: Optional[List[str]] = None,
    ) -> sql.Composed:
        result = ""

        on_conflict = ""
        if conflict_merge_fields is not None:
            if len(conflict_merge_fields) > 0:
                columns_to_update = [
                    column
                    for column in insert_column_list
                    if column not in conflict_merge_fields
                ]
                if len(columns_to_update) == 0:
                    raise ValueError(
                        f"On conflict part cannot be generated without any columns to update. All the "
                        f"columns are listed part of the "
                        f"key for update : {', '.join(conflict_merge_fields)}"
                    )
                on_conflict = (
                    f"ON CONFLICT ({', '.join(conflict_merge_fields)}) DO UPDATE SET\n"
                )
                on_conflict += "\n, ".join(
                    [
                        f"{column_to_update} = EXCLUDED.{column_to_update}"
                        for column_to_update in columns_to_update
                    ]
                )

        # Prepare the INSERT INTO query
        insert_query = sql.SQL(
            "INSERT INTO {}.{} ({}) VALUES %s " + on_conflict + result + ";"
        ).format(
            sql.Identifier(schema_name),
            sql.Identifier(table_name),
            sql.SQL(", ").join(map(sql.Identifier, insert_column_list)),
        )

        return insert_query

    @classmethod
    def create_insert_query_with_internal_selection(
            cls,
            schema_name: str,
            table_name: str,
            selection_query: str,
            insert_column_list: List[str],
            conflict_merge_fields: Optional[List[str]] = None,
            format_additional_args: list[sql.Composable] = [],
    ) -> sql.Composed:
        result = ""

        on_conflict = ""
        if conflict_merge_fields is not None:
            if len(conflict_merge_fields) > 0:
                columns_to_update = [
                    column
                    for column in insert_column_list
                    if column not in conflict_merge_fields
                ]
                if len(columns_to_update) == 0:
                    raise ValueError(
                        f"On conflict part cannot be generated without any columns to update. All the "
                        f"columns are listed part of the "
                        f"key for update : {', '.join(conflict_merge_fields)}"
                    )
                on_conflict = (
                    f"ON CONFLICT ({', '.join(conflict_merge_fields)}) DO UPDATE SET\n"
                )
                on_conflict += "\n, ".join(
                    [
                        f"{column_to_update} = EXCLUDED.{column_to_update}"
                        for column_to_update in columns_to_update
                    ]
                )

        # Prepare the INSERT INTO query
        format_args = [
            sql.Identifier(schema_name),
            sql.Identifier(table_name),
            sql.SQL(", ").join(map(sql.Identifier, insert_column_list)),
        ]
        if len(format_additional_args) > 0:
            format_args += format_additional_args

        insert_query = sql.SQL(
            "INSERT INTO {}.{} ({}) \n" + selection_query + on_conflict + result + ";"
        ).format(*format_args)

        return insert_query