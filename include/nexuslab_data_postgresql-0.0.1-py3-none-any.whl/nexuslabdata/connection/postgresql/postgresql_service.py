import logging
from io import StringIO
from typing import Union, Dict, Any, Optional, List

import numpy as np
import pandas as pd
import psycopg2
from psycopg2.extras import RealDictCursor, execute_values

from nexuslabdata.connection.base import (
    SqlDbService,
    QueryExecResult,
    QueryExecResultStatus,
    QueryWrapper,
)
from nexuslabdata.connection.postgresql.postgresql_connection import (
    PostgreSQLConnectionWrapper,
)
from nexuslabdata.connection.postgresql.postgresql_data_type import (
    PostgreSQLDataTypes,
)
from nexuslabdata.connection.postgresql.postgresql_query_builder import PostgreSQLQueryBuilder
from nexuslabdata.connection.postgresql.postgresql_utils import PostgreSQLUtil
from nexuslabdata.utils.datetime_util import get_current_datetime


class PostgreSQLService(SqlDbService[PostgreSQLConnectionWrapper]):
    """Service class for PostgreSQL connections.
    This class provides methods to execute queries, set schemas, and truncate tables.
    It extends the base DbService class and implements PostgreSQL-specific functionality.
    """

    def __init__(self, connection_wrapper: PostgreSQLConnectionWrapper) -> None:
        """Initialize the PostgreSQL service with a connection wrapper.
        Args:
            connection_wrapper (PostgreSQLConnectionWrapper): The connection wrapper for PostgreSQL.
        """
        super().__init__(connection_wrapper)

    def log_execution_error(self, error: psycopg2.Error) -> None:  # type: ignore[override]
        """Log execution errors.
        Args:
            error (psycopg2.Error): The error to log.
        """
        self.log_error(PostgreSQLUtil.get_standard_error_message(error))

    def get_active_cursor(
        self
    ) -> RealDictCursor:
        assert self.connection_wrapper.connection is not None
        return self.connection_wrapper.connection.cursor(cursor_factory=RealDictCursor)

    def execute_query(self, query: Union[str, QueryWrapper]) -> QueryExecResult:
        """Execute a query using the provided query wrapper.
        Args:
            query_wrapper (QueryWrapper): The query wrapper containing the query and parameters.
        Returns:
            QueryExecResult: The result of the query execution.
        """
        query_wrapper = (
            query
            if isinstance(query, QueryWrapper)
            else QueryWrapper(query=query)
        )
        cur = self.get_active_cursor()
        start_tst = get_current_datetime()
        query_wrapper.update_interpreted_query()
        try:
            cur.execute(query_wrapper.get_interpreted_query())
            results = cur.fetchall() if cur.description else []
            structure = PostgreSQLUtil.get_structure_from_metadata(
                result_metadata=cur.description,
                row_count=len(results),
            )
            return QueryExecResult(
                query_wrapper.name,
                QueryExecResultStatus.SUCCESS,
                query_wrapper.get_interpreted_query(),
                None,
                results,
                structure,
                start_tst,
                get_current_datetime(),
            )
        except psycopg2.Error as e:
            self.log_execution_error(e)
            raise e
        finally:
            cur.close()

    def set_schema_on_connection(self, schema: str) -> QueryExecResult:
        """Set the schema for the connection.
        Args:
            schema (str): The name of the schema to set.
        Returns:
            QueryExecResult: The result of the schema setting operation.
        Raises:
            RuntimeError: If the schema cannot be set.
        """
        return self.execute_query(
            query=QueryWrapper(
                query="SET search_path TO {{ schema }}",
                params={"schema": schema},
                runtime_exception_message=f"Schema {schema} cannot be set",
            ),
        )

    def truncate_table(
        self, schema_name: str, table_name: str
    ) -> QueryExecResult:
        """Truncate a table in the specified schema.
        Args:
            schema_name (str): The name of the schema.
            table_name (str): The name of the table to truncate.
        Returns:
            QueryExecResult: The result of the truncate operation.
        Raises:
            RuntimeError: If the table cannot be truncated.
        """
        query_wrapper = QueryWrapper(
            query="TRUNCATE TABLE {{ schema_name }}.{{ table_name }}",
            params={"schema_name": schema_name, "table_name": table_name},
        )
        return self.execute_query(query=query_wrapper)

    def drop_table(self, schema_name: str, table_name: str) -> QueryExecResult:
        """Drop a table in the specified schema."""
        query_wrapper = QueryWrapper(
            query="DROP TABLE IF EXISTS {{ schema_name }}.{{ table_name }}",
            params={"schema_name": schema_name, "table_name": table_name},
        )
        return self.execute_query(query=query_wrapper)

    def create_table(
        self,
        schema_name: str,
        table_name: str,
        columns: Dict[str, str],
        if_exists: str = "replace",
    ) -> QueryExecResult:
        """Create a table with the given columns. Drops first if if_exists='replace'."""
        if if_exists == "replace":
            self.drop_table(schema_name=schema_name, table_name=table_name)
            logging.info(f"Table {schema_name}.{table_name} dropped")

        cols_defs = ", ".join(
            f'"{col}" {dtype}' for col, dtype in columns.items()
        )
        create_sql = (
            f'CREATE TABLE "{schema_name}"."{table_name}" ({cols_defs})'
        )
        query_wrapper = QueryWrapper(
            query=create_sql,
            params={"schema_name": schema_name, "table_name": table_name},
        )
        return self.execute_query(query=query_wrapper)

    def write_table(
        self,
        df: pd.DataFrame,
        table_name: str,
        schema_name: str = "public",
        if_exists: str = "replace",
    ) -> QueryExecResult:
        """Write a dataframe to a PostgreSQL table."""
        logging.info(f"Writing table {table_name} to schema {schema_name}")
        start_tst = get_current_datetime()

        dtype_map = {
            col: self._map_dtype(dtype)
            for col, dtype in zip(df.columns, df.dtypes)
        }
        self.create_table(schema_name, table_name, dtype_map, if_exists)
        logging.info(f"Table {schema_name}.{table_name} created")

        # INSERT data
        buffer = StringIO()
        df.to_csv(buffer, sep=";", index=False, header=False)
        buffer.seek(0)

        cols_list = ",".join(f'"{col}"' for col in df.columns)
        copy_sql = (
            f'COPY "{schema_name}"."{table_name}" ({cols_list}) '
            f"FROM STDIN WITH (FORMAT csv, DELIMITER ';', NULL '')"
        )

        con = self.connection_wrapper.connection
        assert con is not None
        cur = con.cursor()
        cur.copy_expert(copy_sql, buffer)
        con.commit()
        cur.close()
        buffer.close()
        logging.info(f"Table {schema_name}.{table_name} written")

        return QueryExecResult(
            query_name="write_table",
            exec_status=QueryExecResultStatus.SUCCESS,
            query=copy_sql,
            query_id=None,
            result_set=None,
            result_set_structure=None,
            start_tst=start_tst,
            end_tst=get_current_datetime(),
        )

    def insert_dataframe_to_postgres(
        self,
        dataframe: pd.DataFrame,
        table_name: str,
        schema_name: str,
        conflict_merge_fields: Optional[List[str]] = None,
    ) -> Any | None:
        if self.connection_wrapper.connection is None:
            raise ValueError("Connection is required to execute query")
        if dataframe.shape[0] == 0:
            self.logger.warn(
                f"Empty DataFrame provided for insert into the table {table_name} on schema {schema_name}"
            )
            self.logger.warn("No update on database applied")
        self.logger.info(
            f"Inserting {len(dataframe)} rows into the table {table_name} on schema {schema_name}"
        )

        # Create a connection to the PostgreSQL database
        conn_cursor = self.get_active_cursor()

        load_query = PostgreSQLQueryBuilder.create_load_dataframe_data_query(
            schema_name=schema_name,
            table_name=table_name,
            insert_column_list=list(dataframe.columns),
            conflict_merge_fields=conflict_merge_fields,
        )
        self.logger.info(
            "DataFrame load to be executed using following sql template : "
        )
        self.logger.info(load_query.as_string(self.connection_wrapper.connection))

        # Convert DataFrame to list of tuples for insertion
        values = [
            tuple(row)
            for row in dataframe.replace(np.nan, None).to_records(index=False)
        ]
        try:
            # Execute the INSERT INTO query
            execute_values(
                conn_cursor, load_query, values, template=None, page_size=1000
            )
            # Commit the changes
            self.connection_wrapper.connection.commit()
        except Exception as e:
            # Rollback in case of an error
            self.connection_wrapper.connection.rollback()
            raise e

        finally:
            # Close the conn_cursor and connection
            conn_cursor.close()

        return

    def fetch_table(
        self, table_name: str, schema_name: str = "public"
    ) -> pd.DataFrame:
        """Fetch a table from PostgreSQL and return it as a DataFrame."""
        select_sql = "SELECT * FROM {{ schema_name }}.{{ table_name }}"
        query_wrapper = QueryWrapper(
            query=select_sql,
            params={"schema_name": schema_name, "table_name": table_name},
        )
        result = self.execute_query(query=query_wrapper)
        df = result.get_result_set_as_df()
        logging.info(
            f"Fetched {len(df)} rows from table {schema_name}.{table_name}"
        )
        return df

    def _map_dtype(self, dtype: Any) -> str:
        """Map pandas dtype to PostgreSQL type."""
        if pd.api.types.is_integer_dtype(dtype):
            return PostgreSQLDataTypes.BIGINT
        if pd.api.types.is_float_dtype(dtype):
            return PostgreSQLDataTypes.DOUBLE_PRECISION
        if pd.api.types.is_bool_dtype(dtype):
            return PostgreSQLDataTypes.BOOL
        if pd.api.types.is_datetime64_any_dtype(dtype):
            return PostgreSQLDataTypes.TIMESTAMP
        return PostgreSQLDataTypes.TEXT
