from dataclasses import dataclass
from typing import Optional

from nexuslabdata.connection.base import BaseSqlCredential


@dataclass
class PostgreSQLCredential(BaseSqlCredential):
    """Credential class for PostgreSQL connections.

    This class holds the connection parameters required to connect to a PostgreSQL database.
    """

    name: str
    host: str
    port: str
    user: str
    password: str
    database: Optional[str] = None
    schema: Optional[str] = None

    @property
    def type(self) -> str:
        return "postgresql"
