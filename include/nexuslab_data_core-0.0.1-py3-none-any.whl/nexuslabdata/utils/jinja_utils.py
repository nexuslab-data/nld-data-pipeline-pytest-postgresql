from typing import Any, Optional

from jinja2 import Template

JINJA2_FILE_STANDARD_REGEX = r".*\.jinja2$"


def render_template(
    template_str: Optional[str], *args: Any, **kwargs: Any
) -> str:
    if template_str is None:
        return ""
    return Template(template_str).render(*args, **kwargs).strip()


def render_template_with_none_return_allowed(
    template_str: Optional[str], *args: Any, **kwargs: Any
) -> Optional[str]:
    if template_str is None:
        return None
    render_result = Template(template_str).render(*args, **kwargs).strip()
    return render_result if render_result else None
