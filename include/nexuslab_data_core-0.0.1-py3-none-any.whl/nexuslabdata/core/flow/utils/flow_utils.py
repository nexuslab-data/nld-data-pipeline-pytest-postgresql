from typing import Final

DEFAULT_VALUE: Final[str] = "#"
DEFAULT_VALUE_FOR_INTEGER_ID: Final[int] = -1
