from typing import Optional, List
from dataclasses import dataclass, field

from nexuslabdata.core.structure.structure_adapter import StructureAdapter
from nexuslabdata.utils.data_class_mixin import (
    NldNamedDataClassMixIn,
)


@dataclass
class SQLRenderEntry(NldNamedDataClassMixIn):
    name: str = ""
    # adapter: Optional[str] = None
    adapter: Optional[StructureAdapter] = None


@dataclass
class SQLRendererWrapper(NldNamedDataClassMixIn):
    name: str = ""
    renderer: List[SQLRenderEntry] = field(default_factory=list)
