import os
import re
from typing import Any, List, Dict

from nexuslabdata.project import Project
from nexuslabdata.service import NldServiceWrapper
from nexuslabdata.task.base_task import BaseRunStatus, BaseTask
from nexuslabdata.core.structure.sql_renderer_wrapper import SQLRenderEntry
from nexuslabdata.core.structure import (
    SQLRendererWrapper,
    SQLTemplateWrapper,
)


class StructureSqlRendererTask(BaseTask):
    init_params: List[str] = [
        "project",
    ]
    run_params: List[str] = [
        "structure",
        "renderer",
        "output_folder_name",
        "params",
    ]

    def __init__(self, project: Project, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.project = project

    def _parse_params(self, raw: str) -> Dict[str, str]:
        """Parses the params passed via CLI into a dictionary."""
        if not raw:
            return {"MAJOR": "0", "MINOR": "0"}

        cleaned = raw.strip().lstrip("{").rstrip("}")
        param_pairs = [p.strip() for p in cleaned.split(",") if p.strip()]

        parsed: Dict[str, str] = {}
        for pair in param_pairs:
            if "=" not in pair:
                raise ValueError(f"Invalid param pair: '{pair}'")
            k, v = pair.split("=", 1)
            parsed[k.strip()] = v.strip()

        return parsed

    def _suffix_from_name(self, template_name: str) -> str:
        """Extracts the suffix from a template filename."""
        base = os.path.basename(template_name)
        match = re.match(r".*\.([^.]+)\.sql$", base, flags=re.IGNORECASE)

        if match:
            return match.group(1).lower()
        return os.path.splitext(base)[0].lower()

    def run(  # type: ignore[override]
        self,
        structure: str,
        renderer: str,
        output_folder_name: str,
        *args: str,
        **kwargs: str,
    ) -> bool:
        run_status = BaseRunStatus.SUCCESS.value
        self.log_info("SQL rendering executing")

        # load params
        params = self._parse_params(kwargs["params"])

        # load structure
        nld_service_wrapper: NldServiceWrapper = self.project.obj_service
        current_structure = nld_service_wrapper.get_structure(structure)
        if current_structure is None:
            raise ValueError(f"Structure not found: {structure}")

        renderer_wrapper = nld_service_wrapper.get_sql_renderer(renderer)

        if renderer_wrapper is None and renderer.endswith(".sql"):
            renderer_wrapper = SQLRendererWrapper(
                name=structure,
                renderer=[SQLRenderEntry(name=renderer)],
            )

        if not renderer_wrapper:
            raise ValueError(f"Renderer not found: {renderer}")

        for index, entry in enumerate(renderer_wrapper.renderer, start=1):
            try:
                template_content = self.project.get_template_content(entry.name)
            except FileNotFoundError:
                raise FileNotFoundError(
                    f"Template file not found: {entry.name}"
                )

            adapter = None
            if entry.adapter:
                adapter = nld_service_wrapper.get_structure_adapter(
                    entry.adapter.name
                )
                if adapter is None:
                    raise FileNotFoundError(
                        f"Adapter file not found: {entry.adapter}"
                    )
                self.log_info(f"Using adapter: {adapter.name}")

            wrapper = SQLTemplateWrapper(
                name=entry.name,
                template=template_content,
                structure_adapter=adapter,
            )

            suffix = self._suffix_from_name(entry.name)
            file_name = f"V.{params['MAJOR']}.{params['MINOR']}.{index}_{structure}_{suffix}.sql"

            try:
                wrapper.generate_sql(
                    current_structure, output_folder_name, file_name
                )
            except Exception as e:
                raise ValueError(
                    f"Failed to render SQL statement for {entry.name}: {e}"
                ) from e
        return run_status
